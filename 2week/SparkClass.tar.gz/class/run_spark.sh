#!/bin/sh
SPARK_HOME=/usr/local/spark
CLASS_HOME=/home/class

$SPARK_HOME/bin/spark-submit --class wordcount $CLASS_HOME/wordcount1_2.11-1.0.jar $CLASS_HOME/readme.txt $CLASS_HOME/wordcount
